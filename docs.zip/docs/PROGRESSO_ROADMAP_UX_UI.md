# Progresso — Roadmap UX/UI e Features (App #1)

**Fonte:** `docs/ROADMAP_UX_UI_E_FEATURES_APP1.md` (adicionado 24/08/2026).
**Como usar este arquivo:** é o checklist vivo desse roadmap — cada item vira `[x]` só quando implementado de verdade (código no `main`, `flutter analyze`/`flutter test` passando), com uma nota curta de onde/como. Se pegar este projeto numa sessão nova (IA diferente ou não), comece por aqui: mostra o que já saiu do papel e o que ainda falta, sem precisar reler o roadmap inteiro linha por linha. Atualize os checkboxes conforme for implementando — não deixe o roadmap fonte e este arquivo divergirem.

**Regra de ouro herdada do roadmap (seção 37):** UX melhor > mais features. Diferencial do Obrion (medição integrada) > copiar concorrente. Acabamento no fluxo principal > velocidade de desenvolvimento.

---

## FASE 1 — Polimento UX/UI (P0, seção 28 do roadmap)

| # | Item | Status | Nota |
|---|---|---|---|
| 1 | Auditoria visual de todas as telas | ✅ Feito (26/08/2026) | Passe completo: cor + espaçamento (75 ocorrências AppSpacing), navegação (2 rotas mortas removidas), componentes (Design System 100%), tipografia (1 violação corrigida), responsividade (2 bottom sheets com clamp), loading/erro (try/catch em 2 telas), microcopy (21 correções). Ver docs de revisão. |
| 2 | Home como painel | ✅ Feito (24/08/2026) | `lib/screens/home_screen.dart` + `BudgetsRepository.loadHomeSummary()` — resumo (em orçamentos / aguardando / aprovados / recebidos) + lista de pendências (orçamentos "Enviado", tocável, leva direto pro orçamento). Grade de atalhos (Clientes/Catálogo/Recibos/Listas) **não** entrou — já é redundante com a barra inferior, decisão registrada no `CHANGELOG.md`. |
| 3 | Dados de exemplo | ✅ Feito | `lib/repositories/example_data_seeder.dart` — cliente + orçamento `[exemplo]`, ação "Ver um exemplo" nos estados vazios de Clientes/Orçamentos. |
| 4 | Perfil por profissão | ✅ Feito | Onboarding pergunta "O que você faz?" (múltipla escolha), editável em Ajustes → "Seus ofícios". `Trade` enum em `database/enums.dart`. |
| 5 | Serviços filtrados por profissão | ✅ Feito | `ServicesRepository.populateDefaultServices(trades:)` — "Sugestões" na Lista de Preços filtra pelo ofício do perfil. |
| 6 | Wizard de orçamento | ✅ Feito (26/08/2026) | `lib/screens/budget_wizard_screen.dart` — fluxo guiado de 4 etapas (Serviços → Condições → Revisão → Envio) substituindo o formulário monolítico de 1213 linhas. `BudgetFormScreen` continua para edição. Indicador de progresso, criação de rascunho no início, confirmação ao cancelar, compartilhar PDF/imagem + marcar como enviado na etapa final. Navegação atualizada: `ClientDetailScreen` e `BudgetsListScreen` abrem o wizard para novos orçamentos. |
| 7 | Campos opcionais recolhidos | ✅ Feito | Formulário de cliente: cabeçalho colapsável (seta garantida, controlado à mão) escondendo CPF/CNPJ, Rua, Número, Bairro, Complemento, Observações. |
| 8 | Microcopy | ✅ Feito (26/08/2026) | Revisão completa tela a tela: 21 correções aplicadas em 8 arquivos. Validators ('Informe' → 'Preencha'), settings, onboarding ('cômodo', 'celular'), login (benefício claro), client_form (exemplo concreto), services (linguagem simples), budget_form (sem redundância), wizard (textos curtos/coloquiais). Ver `docs/MICROCOPY_REVISAO_26_08_2026.md`. |
| 9 | Estados vazios | ✅ Feito (24/08/2026) | As 4 telas com `AppEmptyState` (`clients_screen.dart`, `services_screen.dart`, `client_detail_screen.dart`, `budgets_list_screen.dart`) reescritas contra as 3 perguntas da seção 18 ("o que é / por que vazio / o que fazer"). De quebra, corrigido um bug de microcopy em `services_screen.dart`: mostrava a mesma mensagem pra "sem serviço nenhum" e "busca sem resultado" — agora distingue, igual `clients_screen.dart` já fazia. |
| 10 | Feedback de ações | ✅ Feito | `AppSnackBar` em toda ação relevante (salvar, excluir, duplicar, etc.), ícone muda por tipo. |
| 11 | Revisão de navegação | ✅ Feito (24/08/2026) | Achado por grep: as rotas `/clients/new` e `/measurements/:projectId/new` no `go_router` estavam **mortas** — toda navegação real já ia por `Navigator.push(MaterialPageRoute(...))` direto nas telas (arquitetura documentada em `main_shell.dart`). Mesma classe de bug de "código órfão" já vista com `duplicate()`/`softDeleteMeasurement()`. Removidas as duas rotas e `AppRoutes.clientNew`; `go_router` hoje só registra a raiz (`MainShell`), como o comentário do próprio arquivo sempre disse que deveria ser. |
| 12 | Revisão de componentes | ✅ Feito (24/08/2026) | Grep por `TextField`/`ElevatedButton`/`OutlinedButton`/`TextButton` fora do Design System: nenhuma violação — todo campo de texto passa por `AppTextField`, os poucos `TextButton` soltos são o padrão já estabelecido de ação secundária (ex. "Enviar lembrete", "Ver um exemplo"), `ElevatedButton`/`OutlinedButton` só existem dentro de `AppButton`/`AppDialog` (o próprio Design System). Nada pra corrigir. |
| 13 | Revisão de espaçamento/tipografia | ✅ Feito (24/08/2026) | Espaçamento: ver item 1 (75 ocorrências viraram `AppSpacing.*`). Tipografia: grep por `fontSize:` achou só 1 violação real — badge de status em `budgets_list_screen.dart` usava `TextStyle(fontSize: 12)` cru, trocado por `Theme.of(context).textTheme.labelMedium`. Todo `fontSize:` restante é de `lib/pdf/` (exceção válida — documento impresso precisa de tamanho fixo, mesma lógica já aplicada a `PdfColors.*`). |
| 14 | Revisão de loading/erro/sucesso | ✅ Feito (26/08/2026) | Auditoria dedicada completa: 15 ocorrências de `AppLoading`/`AppError` confirmadas, uso consistente em todas as telas. **2 correções aplicadas**: try/catch adicionado em `ClientFormScreen._save()` e `MeasurementFormScreen._save()` (operações críticas sem tratamento de exceção). Ver `docs/REVISAO_LOADING_ERRO_SUCESSO_26_08_2026.md`. |
| 15 | Importar contato | ⏸️ Pendente — **mudança nativa** | Precisa de `flutter_contacts` (ou similar) + permissão `READ_CONTACTS` no `AndroidManifest.xml` → só entra em vigor num release completo (não patch), exige reinstalação. Avaliado em 24/08/2026, não implementado ainda. |
| 16 | Ações rápidas do cliente | ✅ Feito | Botões "WhatsApp"/"Ligar" na ficha do cliente (`lib/utils/phone_actions.dart`), sem `canLaunchUrl` (evita precisar de `<queries>` no manifest — continua patchável). |
| 17 | Melhorar duplicação | ✅ Feito (24/08/2026), parcial | `BudgetsRepository.duplicate()` já existia mas estava **órfão** (nenhuma tela chamava desde que `budgets_screen.dart` foi removido) — corrigido: menu ⋮ no orçamento → "Duplicar orçamento". A UX refinada do roadmap ("O que deseja manter? ☑ Serviços ☑ Preços ☐ Cliente") **não** entrou — duplicar hoje sempre copia serviços/preços/condições pro mesmo cliente, como já era antes de virar órfão. |
| 18 | PDF profissional | ✅ Feito (28/08/2026) | Descrição da obra, assinatura (profissional + contratante com CPF/CNPJ), todos os campos da seção 15 do roadmap presentes. **Melhorado (28/08):** cabeçalho agora exibe telefone + e-mail + endereço comercial do profissional, número sequencial do orçamento como título. `professionalDocument` (CPF/CNPJ) renderizado no cabeçalho. Recibo também exibe telefone + e-mail. |
| 19 | Exportação em imagem | ✅ Feito | `BudgetShareService.shareAsImage`. |
| 20 | Compartilhamento WhatsApp | ✅ Feito | Via `share_plus` (folha do sistema). |
| 21 | Revisão completa de responsividade | ✅ Feito (26/08/2026) | Passe formal completo: 14 telas analisadas, arquitetura responsiva confirmada (uso correto de `Expanded`, `ListView`, `AppSpacing.*`). **2 correções aplicadas**: altura de bottom sheets em `BudgetFormScreen` e `BudgetsListScreen` agora usa `.clamp(400.0, 700.0)` para telas pequenas/grandes. Nenhum problema crítico encontrado. Ver `docs/REVISAO_RESPONSIVIDADE_26_08_2026.md`. |

**Critério de saída da Fase 1 (seção 28):** *"abrir → entender → criar cliente → medir → montar orçamento → gerar documento → compartilhar, sem tutorial manual"* — o fluxo funciona ponta a ponta hoje, mas os itens `⏸️`/`🔶` acima (principalmente wizard e auditoria visual) são o que falta pra dizer que a Fase 1 está **fechada**, não só "funcional".

---

## FASE 2 — Retenção (P1, seção 29 do roadmap)

| # | Item | Status | Nota |
|---|---|---|---|
| 1 | Status de orçamento | ✅ Feito | `rascunho → enviado → aceito/recusado`, um toque. |
| 2 | Área "Aguardando resposta" | ✅ Feito | Home (pendências) + chip na lista de orçamentos. |
| 3 | Follow-up manual | ✅ Feito (24/08/2026) | Botão "Enviar lembrete" (WhatsApp com mensagem pré-pronta, `lib/utils/follow_up_message.dart`) na Home (pendências) e na aba Orçamentos, pra qualquer orçamento "Enviado" com telefone salvo. Nunca envia sozinho — só pré-preenche a conversa. |
| 4 | Histórico do cliente | ✅ Feito | `client_detail_screen.dart`. |
| 5 | Histórico de orçamentos | ✅ Feito | `BudgetsListScreen`. |
| 6 | Controle simples de pagamentos | ✅ Feito | `payments` + resumo Recebido/Pendente no orçamento. |
| 7 | Recibo | ✅ Feito | `ReceiptPdfGenerator`. |
| 8 | Modelos de orçamento | ⏸️ Pendente | Nada implementado — schema novo necessário (`templates`?). Marcado P1/PRO no roadmap. |
| 9 | Melhorias no catálogo | ✅ Feito (24/08/2026) | Reajuste em massa (já feito antes) + categoria/filtro por categoria (seção 5 do roadmap): `services.category` (schema v5→v6, opcional, texto livre — mesma regra de "nunca sugerir preço" aplicada aqui, sem lista fixa inventada), chips de filtro na Lista de Preços (`lib/utils/service_filter.dart`, lógica pura testada). "Duplicar serviço" (também citado na seção 5) não entrou — não avaliado ainda se vale o esforço. |
| 10 | Reajuste de preços | ✅ Feito | Ícone "Reajustar" na Lista de Preços, aceita percentual negativo. |
| 11 | Notificações úteis | ✅ Feito | Lembrete "aguardando resposta" (3 dias) + lembrete de validade (1 dia antes). |

---

## FASE 3 — Conta e Nuvem (P1, seção 30)

Não iniciada — aguardando ★ Validação, conforme roadmap vigente do `CLAUDE.md`. Nenhum item desta fase deve ser adiantado "porque é tecnicamente possível" (regra explícita do roadmap).

## FASE 4 — Monetização (P1, seção 31)

Não iniciada — mesma dependência da Fase 3.

## FASE 5 — Inteligência (P2/P3, seção 32)

Não iniciada — nenhum item de IA deve ser feature de lançamento (regra já em `CLAUDE.md`).

---

## Achados durante esta rodada (24-28/08/2026) que valem registrar

- **`BudgetsRepository.duplicate()` estava órfão** — mesma classe de bug já vista com `MeasurementsRepository.softDeleteMeasurement()`: método existe, testado, mas nenhuma tela chamava. Motivo provável: perdido quando `budgets_screen.dart` foi removido na unificação do histórico do cliente. Corrigido nesta rodada — mas vale conferir se não há mais nenhum método "órfão" no repositório (busca rápida: grep por métodos públicos do repositório vs. chamadas em `lib/screens/`).
- **Home "painel" exigiu uma consulta nova** (`loadHomeSummary`) que varre `budgets`/`budget_items`/`payments`/`clients` inteiros e agrega em memória — aceitável pro volume de um profissional solo, mas **não escala** se o app crescer pra uso com muitos orçamentos/ano. Se isso um dia virar perceptível (tela lenta pra abrir), é o primeiro lugar a otimizar (mover a agregação pra SQL).
- **PDF melhorado (28/08/2026)**: cabeçalho agora exibe telefone + e-mail + endereço do profissional, número sequencial do orçamento, CPF/CNPJ. Perfil ganhou campos `email` e `address`. Onboarding agora coleta nome, telefone, CNPJ e logo na 4ª página.
- **Distribuição corrigida (28/08/2026)**: workflow `build-distribute.yml` agora baixa o APK do Shorebird em vez de compilar separado — evita builds duplicados que divergem do release.
- **5 correções de teste no aparelho (28/08/2026)**: campos invisíveis em formulários, diálogos com botões colados, exclusão de orçamento, status rascunho, "usar medição" sem medição.

---

## Pendências de consistência entre documentos (seção 35 do roadmap)

O roadmap pede uma varredura de contradições entre os `.md` sempre que uma mudança relevante acontece. A varredura foi feita em 26/08/2026 — ver `docs/LIMPEZA_INCONSISTENCIAS_26_08_2026.md`.

- [x] Resíduos de AdMob em `PLANO_DE_NEGOCIO_INICIAL.md`/`APP_FACTORY_RULES.md`/`APP_FACTORY_CORE.md` — **✅ Corrigido 26/08/2026.**
- [x] Conflito de tema `APP_FACTORY_RULES.md` §9 vs. `APP_FACTORY_CORE.md` §8 — **✅ Corrigido 26/08/2026** (ambos agora descrevem seed color + `ColorScheme.fromSeed`).
- [x] `APP_FACTORY_RULES.md` — versão bumped de v0.3 para v0.4 (alterações desde 23/08 não refletidas no cabeçalho) — **✅ Corrigido 26/08/2026.**
- [ ] `PLANO_DE_NEGOCIO_INICIAL.md` — atualizar posicionamento/diferenciais pra refletir a home-painel e a promessa "medição + orçamento" (já defendida em `ANALISE_CONCORRENCIA_E_ESCOPO.md`, Parte 4).
- [ ] `docs/POSICIONAMENTO_E_FEATURES_APP1.md` — Parte 4 já lista vários destes itens como "ideias"; marcar os que saíram do papel (ver tabela acima) em vez de deixar como sugestão em aberto.
- [ ] `APP_FACTORY_CORE.md` — registrar só o que comprovadamente virou padrão reutilizável (regra da seção 34 do roadmap); não adiantar módulos especulativos.

---

## Próximos passos sugeridos (ordem de retorno/esforço)

1. ~~Follow-up manual~~ ✅ feito 24/08/2026.
2. ~~Auditoria visual (cor+espaçamento) + microcopy + estados vazios~~ ✅ feito 24/08/2026 — escopo restrito a espaçamento/cor (item 1) e às 4 telas com `AppEmptyState` (itens 8/9); navegação, componentes, tipografia e responsividade continuam pendentes.
3. **Decidir o wizard** (Fase 1, item 6) — tensão real entre este roadmap (P0) e a decisão anterior de adiar; precisa de conversa com o fundador antes de começar, é a maior mudança estrutural pendente.
4. **Importar contato** (Fase 1, item 15) — só quando houver disposição pra um release completo (não patch) — bom candidato a agrupar com outras mudanças nativas se/quando surgirem.
5. ~~Categoria no catálogo~~ ✅ feito 24/08/2026 — `services.category` + chips de filtro na Lista de Preços.
6. ~~Revisão de navegação/componentes/tipografia~~ ✅ feito 24/08/2026 (itens 11/12/13) — achado real: 2 rotas mortas no `go_router` removidas, 1 caso de tipografia hardcoded corrigido, componentes já estavam 100% consistentes com o Design System.
7. **Revisão de responsividade** (Fase 1, item 21) — o único item da "auditoria visual" original que ainda falta; não dá pra verificar só com análise estática, precisa de teste visual em telas de tamanhos diferentes (aparelho pequeno/grande, ou o emulador/DevTools).
8. **Revisão de loading/erro/sucesso** (Fase 1, item 14) — `AppLoading`/`AppError` já usados consistentemente, mas nunca houve auditoria dedicada (ex.: todo fluxo assíncrono mostra loading? todo erro tem mensagem acionável?).
9. Varredura de consistência dos documentos (seção acima) — baixo risco de código, mas trabalhoso; fazer numa sessão dedicada só a isso.
